let palestine=document.getElementById("palesyineImageContant")
let ball1=document.getElementById("ball1")
let ball2=document.getElementById("ball2")
let ball1raduis=50;
let back1=true;
let ball1x=0;
let ball1y=0;
let x1=4
let y1=3;

let ball2x=0;
let ball2y=0;
let x2=3;
let y2=4;
let ball2raduis=50;

let on=true;
palestine.src="../imgs/imgs/p2.png"


function paletineBack(){
    if(back1){
     palestine.src="../imgs/imgs/p2.png"
     back1=false
    }
    else{
    
        palestine.src="../imgs/imgs/p1.png"
        back1=true
    }
}

let backgroundAction=setInterval('paletineBack();',1000)
let BallAction=setInterval('moveBall1();',50)
let Ball2Action=setInterval('moveBall2();',50)
function onOFF(){
    if(on)
    {
        clearInterval(backgroundAction)
        clearInterval(BallAction)
        clearInterval(Ball2Action)
        on=false
    }
    else{
        backgroundAction=setInterval('paletineBack();',1000)
         BallAction=setInterval('moveBall1();',50)
         Ball2Action=setInterval('moveBall2();',50)
         on=true
    }

}

function moveBall1(){

    ball1raduis=localStorage.getItem("ball1")
    ball1x+=x1
    ball1.style.left=ball1x+"px"
    ball1.style.width=ball1raduis+"px"

if(ball1x==0)
x1=4
else if(ball1x>600-ball1raduis)
x1=-4


ball1y+=y1
ball1.style.top=ball1y+"px"

if(ball1y==0)
y1=3
else if(ball1y>400-ball1raduis)
y1=-3
}

function moveBall2(){
   let  ball2raduis=localStorage.getItem("ball2")
    console.log(ball2raduis)
    ball2x+=x2
    ball2.style.left=ball2x+"px"
    ball2.style.width=ball2raduis+"px"
if(ball2x==0)
x2=3
else if(ball2x>600-ball2raduis)
x2=-3
ball2y+=y2
ball2.style.top=ball2y+"px"
if(ball2y==0)
y2=4
else if(ball2y>400-ball2raduis)
y2=-4
}


