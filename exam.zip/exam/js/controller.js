let slider1=document.getElementById('slider1')
let slider2=document.getElementById('slider2')
document.getElementById('count1').innerText=50;
document.getElementById('precount1').innerText=50;
document.getElementById('count2').innerText=50;
document.getElementById('precount2').innerText=50;

function change1(){
    let val=slider1.value
    console.log("pre")
    
    document.getElementById('precount1').innerText=val;

    localStorage.setItem("ball1",val)
  


}
function change2(){
    let val=slider2.value
    console.log(val)
    document.getElementById('precount2').innerText=val;

    localStorage.setItem("ball2",val)

}